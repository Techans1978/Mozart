<!-- Camunda Modeler CSS (CDN) -->
<link rel="stylesheet" href="https://unpkg.com/camunda-bpmn-js@5/dist/assets/camunda-platform-modeler.css">