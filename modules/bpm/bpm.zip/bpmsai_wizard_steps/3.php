<?php
// modules/bpm/bpmsai_wizard_steps/3.php  (VISUAL HELIX)
if (session_status()===PHP_SESSION_NONE) session_start();
$st = $_SESSION['bpmsai_wizard'] ?? [];
$steps = $st['steps'] ?? [];
if (!is_array($steps)) $steps = [];

// se vazio, inicia com 2 etapas padrão (bem “lúdico”)
if (!$steps) {
  $steps = [
    [
      'id'=>'abertura',
      'name'=>'Abertura',
      'type'=>'human',
      'description'=>'Analista preenche dados e anexa documentos.',
      'assignees'=>[['type'=>'perfil','key'=>0,'label'=>'(definir)']],
      'observers'=>[],
      'actions'=>[
        'approve'=>['label'=>'Enviar'],
        'reject'=>['label'=>'Reprovar'],
        'revise'=>['label'=>'Pedir correção']
      ]
    ],
    [
      'id'=>'gerente',
      'name'=>'Gerente',
      'type'=>'human',
      'description'=>'Gerente analisa e decide.',
      'assignees'=>[['type'=>'perfil','key'=>0,'label'=>'(definir)']],
      'observers'=>[],
      'actions'=>[
        'approve'=>['label'=>'Aprovar'],
        'reject'=>['label'=>'Reprovar'],
        'revise'=>['label'=>'Pedir correção']
      ]
    ],
  ];
}
?>

<style>
/* Helix-like cards (lúdico e claro) */
.bpmsai-canvas { display:flex; flex-direction:column; gap:14px; }
.bpmsai-card {
  border:1px solid #e6e6e6; border-radius:10px; background:#fff;
  box-shadow:0 1px 2px rgba(0,0,0,.04);
}
.bpmsai-card-header {
  padding:12px 14px; border-bottom:1px solid #f0f0f0;
  display:flex; align-items:center; justify-content:space-between; gap:10px;
}
.bpmsai-title { display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
.bpmsai-badge { display:inline-flex; align-items:center; gap:6px; padding:3px 8px; border-radius:999px; background:#f7f7f7; font-size:12px; }
.bpmsai-index {
  width:26px; height:26px; border-radius:999px; background:#337ab7; color:#fff;
  display:inline-flex; align-items:center; justify-content:center; font-weight:700; font-size:12px;
}
.bpmsai-card-body { padding:14px; }
.bpmsai-grid { display:grid; grid-template-columns: 1fr 1fr; gap:12px; }
@media (max-width: 992px){ .bpmsai-grid { grid-template-columns:1fr; } }

.bpmsai-chips { display:flex; flex-wrap:wrap; gap:6px; padding:8px; border:1px dashed #ddd; border-radius:8px; min-height:44px; }
.bpmsai-chip {
  display:inline-flex; align-items:center; gap:6px;
  padding:6px 10px; border-radius:999px; background:#f5f8ff; border:1px solid #dbe6ff;
  font-size:12px;
}
.bpmsai-chip .x { cursor:pointer; opacity:.7; }
.bpmsai-chip .x:hover { opacity:1; }
.bpmsai-chip.ob { background:#f7fff6; border-color:#dff3db; }
.bpmsai-mini { font-size:12px; color:#777; margin-top:6px; }

.bpmsai-actions-row { display:flex; gap:8px; flex-wrap:wrap; margin-top:8px; }
.bpmsai-actions-row .labelbox { display:flex; align-items:center; gap:8px; }
.bpmsai-actions-row input { width:160px; }

.bpmsai-footerbar { display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap; margin-top:12px; }
.bpmsai-addbtn { border:1px dashed #cbd5e1; background:#fbfbfb; border-radius:10px; padding:14px; text-align:center; cursor:pointer; }
.bpmsai-addbtn:hover { background:#f7f7f7; }
.bpmsai-danger { color:#b00020; }
.bpmsai-muted { color:#777; }
</style>

<form method="post" action="/modules/bpm/bpmsai_wizard_steps/save.php?step=3" id="bpmsai_form_step3">
  <div class="bpmsai-canvas" id="bpmsai_canvas"></div>

  <div class="bpmsai-addbtn" id="bpmsai_add_step">
    <strong>+ Adicionar etapa</strong>
    <div class="bpmsai-mini">Crie etapas como blocos (sem desenhar BPM)</div>
  </div>

  <!-- hidden que o save.php já espera -->
  <textarea name="steps_json" id="steps_json" class="hidden" style="display:none;"></textarea>

  <div class="bpmsai-footerbar">
    <div class="bpmsai-mini">
      Dica: use nomes curtos. “Correção” depois você escolhe o destino no passo 4.
    </div>
    <div class="text-right">
      <a class="btn btn-default" href="/modules/bpm/bpmsai-wizard.php?step=2">Voltar</a>
      <button class="btn btn-primary" type="submit">Salvar e avançar</button>
    </div>
  </div>
</form>

<!-- Modal simples (Bootstrap) -->
<div class="modal fade" id="bpmsaiPicker" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Adicionar participante</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label>Tipo</label>
          <select class="form-control" id="pick_type">
            <option value="user">Usuário</option>
            <option value="group">Grupo</option>
            <option value="perfil">Perfil</option>
          </select>
        </div>

        <div class="form-group">
          <label>Buscar</label>
          <input class="form-control" id="pick_q" placeholder="Digite para buscar...">
          <div class="bpmsai-mini">Ex.: “Mayara”, “Gerentes”, “RH”.</div>
        </div>

        <div class="list-group" id="pick_results" style="max-height:240px; overflow:auto;"></div>
        <div class="bpmsai-mini bpmsai-muted">Clique em um resultado para adicionar.</div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-default" data-dismiss="modal">Fechar</button>
      </div>
    </div>
  </div>
</div>

<script>
(function(){
  // Estado em memória
  let steps = <?php echo json_encode($steps, JSON_UNESCAPED_UNICODE); ?>;

  // Normaliza estrutura
  function ensureDefaults(s){
    if(!s.type) s.type = 'human';
    if(!Array.isArray(s.assignees)) s.assignees = [];
    if(!Array.isArray(s.observers)) s.observers = [];
    if(!s.actions || typeof s.actions!=='object'){
      s.actions = {
        approve:{label:'Aprovar'},
        reject:{label:'Reprovar'},
        revise:{label:'Pedir correção'}
      };
    } else {
      if(!s.actions.approve) s.actions.approve={label:'Aprovar'};
      if(!s.actions.reject)  s.actions.reject ={label:'Reprovar'};
      if(!s.actions.revise)  s.actions.revise ={label:'Pedir correção'};
    }
    return s;
  }

  function slugify(v){
    return (v||'')
      .toString().trim().toLowerCase()
      .replace(/[^\w\- ]+/g,'')
      .replace(/\s+/g,'_')
      .replace(/\_+/g,'_')
      .slice(0,40) || 'etapa';
  }

  function uniqId(base){
    let id = slugify(base);
    let i = 1;
    const exists = (x)=>steps.some(s=>s.id===x);
    while(exists(id)){ id = slugify(base)+'_'+(i++); }
    return id;
  }

  function chipHtml(p, mode, stepIdx, pIdx){
    const cls = mode==='observers' ? 'bpmsai-chip ob' : 'bpmsai-chip';
    const tLabel = (p.type==='user'?'Usuário':(p.type==='group'?'Grupo':'Perfil'));
    return `
      <span class="${cls}">
        <strong>${tLabel}:</strong> ${escapeHtml(p.label||'')}
        <span class="bpmsai-muted">#${p.key||0}</span>
        <span class="x" title="Remover" data-step="${stepIdx}" data-mode="${mode}" data-idx="${pIdx}">&times;</span>
      </span>`;
  }

  function escapeHtml(str){
    return (str||'').toString()
      .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
      .replaceAll('"','&quot;').replaceAll("'","&#039;");
  }

  function render(){
    const canvas = document.getElementById('bpmsai_canvas');
    canvas.innerHTML = '';

    steps = steps.map(ensureDefaults);

    steps.forEach((s, i)=>{
      const idx = i+1;

      const ass = (s.assignees||[]).map((p,pi)=>chipHtml(p,'assignees',i,pi)).join('') || `<span class="bpmsai-mini bpmsai-muted">Nenhum responsável. Clique em “+” para adicionar.</span>`;
      const obs = (s.observers||[]).map((p,pi)=>chipHtml(p,'observers',i,pi)).join('') || `<span class="bpmsai-mini bpmsai-muted">Sem observadores.</span>`;

      const card = document.createElement('div');
      card.className = 'bpmsai-card';
      card.innerHTML = `
        <div class="bpmsai-card-header">
          <div class="bpmsai-title">
            <span class="bpmsai-index">${idx}</span>

            <div style="min-width:240px;">
              <div class="form-group" style="margin:0">
                <input class="form-control input-sm" data-k="name" data-i="${i}" value="${escapeHtml(s.name||'')}" placeholder="Nome da etapa (ex: Gerente)">
              </div>
            </div>

            <span class="bpmsai-badge">
              ID:
              <input class="form-control input-sm" style="width:170px" data-k="id" data-i="${i}"
                value="${escapeHtml(s.id||'')}" placeholder="id (ex: gerente)">
            </span>

            <span class="bpmsai-badge">
              Tipo:
              <select class="form-control input-sm" style="width:160px" data-k="type" data-i="${i}">
                <option value="human" ${s.type==='human'?'selected':''}>Humana</option>
                <option value="integration" ${s.type==='integration'?'selected':''}>Integração</option>
              </select>
            </span>
          </div>

          <div>
            <button type="button" class="btn btn-xs btn-danger" data-del="${i}" title="Excluir etapa">
              <i class="fa fa-trash"></i> Excluir
            </button>
          </div>
        </div>

        <div class="bpmsai-card-body">
          <div class="form-group">
            <label>Descrição (IA)</label>
            <textarea class="form-control" rows="3" data-k="description" data-i="${i}"
              placeholder="Descreva em 1–3 frases o que acontece nesta etapa...">${escapeHtml(s.description||'')}</textarea>
          </div>

          <div class="bpmsai-grid">
            <div>
              <label>Responsáveis (podem agir)</label>
              <div class="bpmsai-chips" id="ass_${i}">
                ${ass}
              </div>
              <div class="bpmsai-actions-row">
                <button type="button" class="btn btn-xs btn-default" data-add="${i}" data-mode="assignees">
                  + Adicionar responsável
                </button>
              </div>
            </div>

            <div>
              <label>Observadores (somente visualizam)</label>
              <div class="bpmsai-chips" id="obs_${i}">
                ${obs}
              </div>
              <div class="bpmsai-actions-row">
                <button type="button" class="btn btn-xs btn-default" data-add="${i}" data-mode="observers">
                  + Adicionar observador
                </button>
              </div>
            </div>
          </div>

          <hr>

          <label>Ações (labels)</label>
          <div class="bpmsai-actions-row">
            <div class="labelbox">
              <span class="bpmsai-badge">Aprovar</span>
              <input class="form-control input-sm" data-k="action_approve" data-i="${i}" value="${escapeHtml(s.actions.approve.label||'Aprovar')}">
            </div>
            <div class="labelbox">
              <span class="bpmsai-badge">Reprovar</span>
              <input class="form-control input-sm" data-k="action_reject" data-i="${i}" value="${escapeHtml(s.actions.reject.label||'Reprovar')}">
            </div>
            <div class="labelbox">
              <span class="bpmsai-badge">Correção</span>
              <input class="form-control input-sm" data-k="action_revise" data-i="${i}" value="${escapeHtml(s.actions.revise.label||'Pedir correção')}">
            </div>
          </div>

          <div class="bpmsai-mini">
            “Destinos” (aprovar/correção) você define no <b>passo 4</b>.
            “Reprovar” finaliza por padrão.
          </div>
        </div>
      `;
      canvas.appendChild(card);
    });

    syncHidden();
  }

  function syncHidden(){
    // Antes de salvar, remove “placeholders” label (definir)
    const clean = steps.map(s=>{
      const c = JSON.parse(JSON.stringify(s));
      (c.assignees||[]).forEach(p=>{
        if(p.label==='(definir)' && (!p.key || p.key===0)) p.label='';
      });
      return c;
    });
    document.getElementById('steps_json').value = JSON.stringify(clean, null, 2);
  }

  function addStep(){
    const baseName = 'Nova Etapa';
    const id = uniqId(baseName);
    steps.push({
      id,
      name: baseName,
      type: 'human',
      description: '',
      assignees: [],
      observers: [],
      actions: {
        approve:{label:'Aprovar'},
        reject:{label:'Reprovar'},
        revise:{label:'Pedir correção'}
      }
    });
    render();
    // scroll para o fim
    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
  }

  // ===== picker modal state =====
  let pickStepIndex = null;
  let pickMode = null;
  function openPicker(stepIndex, mode){
    pickStepIndex = stepIndex;
    pickMode = mode;
    document.getElementById('pick_q').value = '';
    document.getElementById('pick_results').innerHTML = '';
    $('#bpmsaiPicker').modal('show');
    setTimeout(()=>document.getElementById('pick_q').focus(), 200);
  }

  async function searchPicker(){
    const type = document.getElementById('pick_type').value;
    const q = document.getElementById('pick_q').value || '';
    const resBox = document.getElementById('pick_results');
    resBox.innerHTML = '<div class="bpmsai-mini bpmsai-muted">Buscando...</div>';

    const url = '/modules/bpm/api/bpmsai_assignee_search.php?type='+encodeURIComponent(type)+'&q='+encodeURIComponent(q);
    const r = await fetch(url);
    const j = await r.json();
    if(!j || !j.ok){
      resBox.innerHTML = '<div class="bpmsai-mini bpmsai-danger">Falha na busca.</div>';
      return;
    }
    const items = j.items || [];
    if(!items.length){
      resBox.innerHTML = '<div class="bpmsai-mini bpmsai-muted">Nenhum resultado.</div>';
      return;
    }
    resBox.innerHTML = '';
    items.forEach(it=>{
      const a = document.createElement('a');
      a.href = '#';
      a.className = 'list-group-item';
      a.innerHTML = `<strong>${escapeHtml(it.label)}</strong>
        <div class="bpmsai-mini">${escapeHtml(it.type)} #${it.key} ${it.extra?('— '+escapeHtml(it.extra)):""}</div>`;
      a.addEventListener('click', (ev)=>{
        ev.preventDefault();
        addParticipant(it);
      });
      resBox.appendChild(a);
    });
  }

  function addParticipant(it){
    if(pickStepIndex===null || pickMode===null) return;
    const s = steps[pickStepIndex];
    if(!s) return;

    const arr = (pickMode==='observers') ? s.observers : s.assignees;
    // evita duplicar (mesmo type + key)
    if(arr.some(p=>p.type===it.type && String(p.key)===String(it.key))){
      $('#bpmsaiPicker').modal('hide');
      return;
    }
    arr.push({ type: it.type, key: it.key, label: it.label });
    $('#bpmsaiPicker').modal('hide');
    render();
  }

  // ===== listeners =====
  document.getElementById('bpmsai_add_step').addEventListener('click', addStep);

  document.addEventListener('click', function(e){
    const del = e.target.closest('[data-del]');
    if(del){
      const i = parseInt(del.getAttribute('data-del'),10);
      if(Number.isInteger(i) && steps[i]){
        if(confirm('Excluir esta etapa?')){
          steps.splice(i,1);
          render();
        }
      }
      return;
    }

    const add = e.target.closest('[data-add]');
    if(add){
      const i = parseInt(add.getAttribute('data-add'),10);
      const mode = add.getAttribute('data-mode');
      openPicker(i, mode);
      return;
    }

    const x = e.target.closest('.x[data-step][data-mode][data-idx]');
    if(x){
      const si = parseInt(x.getAttribute('data-step'),10);
      const mode = x.getAttribute('data-mode');
      const pi = parseInt(x.getAttribute('data-idx'),10);
      const s = steps[si];
      if(s){
        const arr = (mode==='observers') ? s.observers : s.assignees;
        arr.splice(pi,1);
        render();
      }
      return;
    }
  });

  document.addEventListener('input', function(e){
    const el = e.target;
    if(!el || !el.matches('[data-k][data-i]')) return;
    const i = parseInt(el.getAttribute('data-i'),10);
    const k = el.getAttribute('data-k');
    const s = steps[i];
    if(!s) return;

    if(k==='name'){
      s.name = el.value;
      // se id vazio, sugere id
      if(!s.id || s.id.trim()===''){
        s.id = uniqId(el.value);
        render(); // atualiza na tela
        return;
      }
    }
    if(k==='id'){ s.id = slugify(el.value); }
    if(k==='type'){ s.type = el.value; }
    if(k==='description'){ s.description = el.value; }

    if(k==='action_approve'){ s.actions.approve.label = el.value; }
    if(k==='action_reject'){ s.actions.reject.label = el.value; }
    if(k==='action_revise'){ s.actions.revise.label = el.value; }

    syncHidden();
  });

  // modal search controls
  document.getElementById('pick_type').addEventListener('change', searchPicker);
  document.getElementById('pick_q').addEventListener('input', function(){
    clearTimeout(window.__bpmsai_t);
    window.__bpmsai_t = setTimeout(searchPicker, 250);
  });
  $('#bpmsaiPicker').on('shown.bs.modal', function(){ searchPicker(); });

  // submit validation
  document.getElementById('bpmsai_form_step3').addEventListener('submit', function(ev){
    // valida mínimo
    const ids = new Set();
    for(const s of steps){
      if(!s.name || !s.name.trim()){ alert('Uma etapa está sem nome.'); ev.preventDefault(); return; }
      if(!s.id || !s.id.trim()){ alert('Uma etapa está sem ID.'); ev.preventDefault(); return; }
      if(ids.has(s.id)){ alert('ID repetido: '+s.id); ev.preventDefault(); return; }
      ids.add(s.id);
      if(!Array.isArray(s.assignees) || s.assignees.length===0){
        if(!confirm('Há etapa sem responsável. Deseja salvar mesmo assim?')){ ev.preventDefault(); return; }
      }
    }
    syncHidden();
  });

  // init
  render();
})();
</script>
